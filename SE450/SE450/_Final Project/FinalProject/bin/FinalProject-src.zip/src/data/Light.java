package data;

public interface Light {
	//TODO
	/*
	 * 
	 */
	
}
