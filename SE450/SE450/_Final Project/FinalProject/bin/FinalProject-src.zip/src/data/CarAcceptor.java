package data;

public interface CarAcceptor {
	public boolean accept(Car c, double frontPosition);
	
	
}
