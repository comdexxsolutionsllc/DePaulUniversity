package data;

public interface Agent {
	public void run();

}
