package world;

public interface Light {
	//TODO
	/*
	 * 
	 */
	
}
