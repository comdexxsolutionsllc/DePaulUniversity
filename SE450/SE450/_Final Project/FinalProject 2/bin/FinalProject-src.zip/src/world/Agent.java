package world;

public interface Agent {
	public void run();

}
