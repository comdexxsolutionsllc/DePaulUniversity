package headfirst.combining.ducks;

public interface Quackable {
	public void quack();
}
