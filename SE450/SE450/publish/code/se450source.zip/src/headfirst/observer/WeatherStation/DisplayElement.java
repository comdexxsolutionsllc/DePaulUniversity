package headfirst.observer.WeatherStation;

public interface DisplayElement {
	public void display();
}
