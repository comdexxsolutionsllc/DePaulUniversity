package factory.shape1;
import java.awt.Graphics;
public class Circle implements Shape {
  public void paint(Graphics g) { /* ... */ }
  // ...
}
