package clone.factory;
public class A {
  protected A() { }
}
