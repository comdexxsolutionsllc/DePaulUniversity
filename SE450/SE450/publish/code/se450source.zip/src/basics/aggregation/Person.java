package basics.aggregation;
final class Person {
  final private String _name;
  public Person(String name) { _name = name; }
  public String toString() { return "Person(" + _name + ")"; };
}
