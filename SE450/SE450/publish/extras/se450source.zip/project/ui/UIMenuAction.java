package project.ui;

public interface UIMenuAction {
  public void run();
}
