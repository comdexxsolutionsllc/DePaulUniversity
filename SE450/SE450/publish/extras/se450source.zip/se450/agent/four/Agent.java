package agent.four;

public interface Agent {
  public void check();
  public void run();
}
