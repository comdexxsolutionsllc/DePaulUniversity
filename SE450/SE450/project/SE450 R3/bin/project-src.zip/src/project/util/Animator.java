
//**********************************************************
// Assignment: Final Project - SE450
//
// Author: 
//
// File: Animator.java
// 
// Date: 
//
// Change Log:  None
//
// Notes: SE450 Included Source  
//*********************************************************


package project.util;
import java.util.Observer;

/**
 * An interface for displaying simulations.
 */
public interface Animator extends Observer {
	public void dispose();
}
