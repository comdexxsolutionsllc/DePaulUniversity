
//**********************************************************
// Assignment: Final Project - SE450
//
// Author: 
//
// File: Agent.java
// 
// Date: 
//
// Change Log:  None
//
// Notes: SE450 Included Source
//*********************************************************


package project.model;

/**
 * Interface for active model objects.
 */
public interface Agent {
	public void run(double time);
}
