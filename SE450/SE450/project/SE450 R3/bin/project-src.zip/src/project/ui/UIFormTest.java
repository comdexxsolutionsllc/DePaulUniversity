
//**********************************************************
// Assignment: Final Project - SE450
//
// Author:
//
// File: UIFormTest.java
// 
// Date: 
//
// Change Log:  None
//
// Notes: SE450 Included Source
//*********************************************************


package project.ui;

public interface UIFormTest {
	public boolean run(String input);
}
