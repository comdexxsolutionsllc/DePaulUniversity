
//**********************************************************
// Assignment: Final Project - SE450
//
// Author:
//
// File: UIError.java
// 
// Date: 
//
// Change Log:  None
//
// Notes: SE450 Included Source  
//*********************************************************


package project.ui;

public class UIError extends Error {
	private static final long serialVersionUID = 2008L;
}
