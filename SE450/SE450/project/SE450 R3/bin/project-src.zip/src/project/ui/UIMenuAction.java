
//**********************************************************
// Assignment: Final Project - SE450
//
// Author: 
//
// File: UIMenuAction.java
// 
// Date: 
//
// Change Log:  None
//
// Notes: SE450 Included Source 
//*********************************************************


package project.ui;

public interface UIMenuAction {
	public void run();
}
