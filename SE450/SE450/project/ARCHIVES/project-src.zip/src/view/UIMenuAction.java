package view;

public interface UIMenuAction {
  public void run();
}
