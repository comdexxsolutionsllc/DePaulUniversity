package view;

public interface UIFormTest {
  public boolean run(String input);
}
