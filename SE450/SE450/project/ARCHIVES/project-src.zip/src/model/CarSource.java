package model;

public interface CarSource {
	
	public void setNextRoad(CarAcceptor road);

}
