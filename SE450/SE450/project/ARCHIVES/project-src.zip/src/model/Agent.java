package model;

public interface Agent {
	
	public void run (double _time);

}


