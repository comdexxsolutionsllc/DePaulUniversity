package project.ui;

/**
 * @author Joshua S Abbott <joshuastevenabbott@gmail.com>
 * 
 */
public class UIError extends Error {
	private static final long serialVersionUID = 2014L;
}
