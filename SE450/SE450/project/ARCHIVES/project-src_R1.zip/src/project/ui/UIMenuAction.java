package project.ui;

/**
 * @author Joshua S Abbott <joshuastevenabbott@gmail.com>
 * 
 */
public interface UIMenuAction {
	public void run();
}
