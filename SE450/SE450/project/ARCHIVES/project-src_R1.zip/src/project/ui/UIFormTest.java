package project.ui;

/**
 * @author Joshua S Abbott <joshuastevenabbott@gmail.com>
 * 
 */
public interface UIFormTest {
	public boolean run(String input);
}
