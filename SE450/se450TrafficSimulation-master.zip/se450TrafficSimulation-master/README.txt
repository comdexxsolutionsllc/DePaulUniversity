README.txt

To run the traffic simulation program, compile all source code and run ../main/Main

The program has a text UI that will provide instructions to customize and execute a simulation.